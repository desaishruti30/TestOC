package OpenCartPages;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class DataInsertAndSubmitRegiPage {
	//Page Factory or Object Repository(OR) for Privacy Policy checkbox
	@FindBy(name="firstname")
	WebElement firstname;
	
	@FindBy(name="lastname")
	WebElement lastname;
	
	@FindBy(name="email")
	WebElement email;
	
	@FindBy(name="telephone")
	WebElement telephone;
	
	@FindBy(name="password")
	WebElement password;
	
	@FindBy(name="password Confirm")
	WebElement confirm;
	
	//Radio Buttons
	@FindBy(xpath="//div[@class='col-sm-10']/label[1]")
	WebElement subscribeYes;
	
	@FindBy(xpath="//div[@class='col-sm-10']/label[2]")
	WebElement subscribeNo;
	
	@FindBy(xpath="//b[contains(text(),'Privacy Policy')]")
	WebElement pplabel;
			
	@FindBy(xpath="//input[@type='checkbox']")
	WebElement ppchbox;
	
//Page Factory or Object Repository(OR) for continue button
	
	@FindBy(xpath="//input[@type='submit']")
	WebElement continuebtn;
	
	
		public RegiSuccessPage EnterDataAndSubmit(String ftName, String ltName, String em, String tele, String pw, String cpw) {
		
		firstname.sendKeys(ftName);
		lastname.sendKeys(ltName);
		email.sendKeys(em);
		telephone.sendKeys(tele);
		password.sendKeys(pw);
		confirm.sendKeys(cpw);
		subscribeYes.click();
		subscribeNo.click();
		ppchbox.click();
		continuebtn.click();
		
		return new RegiSuccessPage();	
	}


		}
