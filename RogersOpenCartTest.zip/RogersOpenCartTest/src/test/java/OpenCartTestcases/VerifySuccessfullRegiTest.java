package OpenCartTestcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import OpenCartBase.TestBase;
import OpenCartPages.DataInsertAndSubmitRegiPage;
import OpenCartPages.RegiSuccessPage;
import OpenCartUtil.TestUtil;


public class VerifySuccessfullRegiTest extends TestBase {
	
	RegiSuccessPage regiSuccessPage;
	TestUtil testUtil;
	DataInsertAndSubmitRegiPage dataInsertAndSubmitRegiPage;
	
	String sheetName = "RegiPage";
	
	 
	public VerifySuccessfullRegiTest(){
		super();
	}
	
@BeforeMethod //initialization 
	
	public void initialization() throws InterruptedException{
		initialize();
		regiSuccessPage = new RegiSuccessPage();
		testUtil = new TestUtil();
		dataInsertAndSubmitRegiPage =new DataInsertAndSubmitRegiPage();
		//testUtil.switchToFrame();
		
		
	}
	
	@AfterMethod
	
	public void tearDown(){
		driver.quit();
	}
	
	
	 @Test
	public void SuccessRegiPagelabelTest(){
	String Heading = regiSuccessPage.verifySuccessRegiPageTitle();
	Assert.assertEquals(Heading, "Register Account");
	}
	
	/*@Test
	public void SuccessRegiPagemsgTest(){
		String sm2 = regiSuccessPage.verifySuccesspagemsg2();
		Assert.assertEquals(sm2, "Congratulations! Your new account has been successfully created!");
	}*/
	
	
	
	@Test(priority =1)
	public void EnterDataTest() {
		dataInsertAndSubmitRegiPage.EnterDataAndSubmit("Tom","Mazz","tmazz@gmail.com","373473487","Test1","Test1");
	
	
	}
/*	@DataProvider
	public Object[][] getOpenCartTestData(){
		Object data[][] = TestUtil.getTestData(sheetName);
		return data;
	}*/
	
	
	
	//@Test
	public void SuccessRegiPagemsgTest(){
		String sm2 = regiSuccessPage.verifySuccesspagemsg2();
		Assert.assertEquals(sm2, "Congratulations! Your new account has been successfully created!");
	}

}
